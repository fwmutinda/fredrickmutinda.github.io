# Data Analysis Exercises

This section showcases sample exercises in **data cleaning, visualization, and automation** using Excel.  
These examples simulate how financial datasets can be transformed into actionable insights.

### 🧰 Skills Demonstrated
- Pivot tables & dashboards  
- Conditional formatting for trend detection  
- Lookup functions and dynamic formulas  
- Data-driven decision-making  

---

📫 **Contact:** [fwmutinda@gmail.com](mailto:fwmutinda@gmail.com)  
🔗 **LinkedIn:** [linkedin.com/in/fredrickmutinda](https://linkedin.com/in/fredrickmutinda)
