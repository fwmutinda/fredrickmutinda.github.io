# Credit Risk Dashboard

This project demonstrates how data analytics can enhance **credit portfolio monitoring** and **delinquency management**.

### 📊 Objective
To build a dashboard that tracks loan performance, delinquency rates, and recovery efficiency in real-time.

### 🧠 Tools Used
- Microsoft Excel (Pivot Tables, Charts, Conditional Formatting)
- Power BI (optional enhancement)

### 📈 Key Metrics
- Portfolio Value by Segment  
- Delinquency Rate (%)  
- Recovery Trend  
- Credit Risk Exposure

### 💡 Insights
By leveraging Excel automation and data visualization, I demonstrated how institutions can identify high-risk segments, predict potential defaults, and improve collection strategies.

---

📫 **Contact:** [fwmutinda@gmail.com](mailto:fwmutinda@gmail.com)  
🔗 **LinkedIn:** [linkedin.com/in/fredrickmutinda](https://linkedin.com/in/fredrickmutinda)
