# Financial Analysis Model

This project presents a **financial performance analysis tool** that evaluates profitability, liquidity, and solvency using real-world banking data structures.

### 🎯 Objective
To demonstrate how financial ratios and key performance indicators can be automated and visualized for better decision-making.

### 📊 Included Metrics
- Return on Assets (ROA)  
- Current Ratio  
- Net Profit Margin  
- Debt-to-Equity Ratio  

### 🧮 Tools & Techniques
- Excel formulas and lookup functions  
- Data modeling using structured references  
- Automated ratio calculation templates

---

📫 **Contact:** [fwmutinda@gmail.com](mailto:fwmutinda@gmail.com)  
🔗 **LinkedIn:** [linkedin.com/in/fredrickmutinda](https://linkedin.com/in/fredrickmutinda)
